package fr.florian4600.serverutils;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3264;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import net.minecraft.class_3518;
import net.minecraft.class_5250;
import net.minecraft.class_6861;
import net.minecraft.server.MinecraftServer;
import org.apache.commons.io.IOUtils;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

public class Translatable {

    public HashMap<String, String> translations = new HashMap<>();

    public Translatable(Logger logger, MinecraftServer server, String modId, String lang) {

        String langFile = String.format(Locale.ROOT, "lang/%s.json", lang);
        class_3300 assetsResources = new class_6861(class_3264.field_14188, server.method_34864().method_29213().toList());
        List<class_3298> resourceStack = assetsResources.method_14489(class_2960.method_60655(modId, langFile));

        for (class_3298 resource : resourceStack) {
            try (InputStream stream = resource.method_14482()) {

                JsonElement jsonelement = new Gson().fromJson(new InputStreamReader(stream, StandardCharsets.UTF_8), JsonElement.class);
                JsonObject jsonobject = class_3518.method_15295(jsonelement, "strings");

                jsonobject.entrySet().forEach(entry -> {
                    String parsedEntry = Pattern.compile("%(\\d+\\$)?[\\d.]*[df]").matcher(class_3518.method_15287(entry.getValue(), entry.getKey())).replaceAll("%$1s");
                    translations.put(entry.getKey(), parsedEntry);
                });

                IOUtils.closeQuietly(stream);

            } catch(IOException e) {
                logger.error("Failed to read locale data {}", resource.toString(), e);
            }
        }

    }

    public Translatable() {
        // Dummy Translatable
    }

    public String translate(String key, Object ...args) {
        return translations.getOrDefault(key, key).formatted(args);
    }

    public class_5250 translateToComponent(String key, Object ...args) {
        return class_2561.method_43470(translate(key, args));
    }

    public class_5250 translateToColoredComponent(String key, class_124 color, Object ...args) {
        return translateToComponent(key, args).method_27694(style -> style.method_10977(color));
    }

}
